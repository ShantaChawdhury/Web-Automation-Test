package packagebatch12;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class twelveclass1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
//		WebDriver initialization
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		
//		Wepage Decleration
//		
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
//		login
//		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		Thread.sleep(4000);
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
//		TitleMatch
		String ExpectedTitle = "Swag Labs";
		String ActualTitle = driver.getTitle();
		if(ActualTitle.equals(ExpectedTitle)) {
			System.out.println("Title Match");
		}
		else {
			System.out.println("Title Doesn't Match");
		}
		
		String ExpectedUrl ="https://www.saucedemo.com/";
		String ActualUrl = driver.getCurrentUrl();
		if(ActualUrl.equals(ExpectedUrl)) {
			System.out.println("Url Match");
		}
		else {
			System.out.println("Url Doesn't Match");
		}
		

	}

}
